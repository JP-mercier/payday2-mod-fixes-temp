---@class EHIWaypoint
---@field new fun(self: self, waypoint: Waypoint?, params: table): self
---@field _parent_class EHIWaypointManager Added when `EHIWaypointManager` class is created
---@field _DEFAULT_COLOR Color?
---@field _force_format boolean Forces formatting (some waypoints need it and will force it)
---@field _forced_time number? Forces specific time in the waypoint
EHIWaypoint = class()
EHIWaypoint._needs_update = true
EHIWaypoint._fade_time = 5
EHIWaypoint._ARROW_COLOR = Color.white
EHIWaypoint._BITMAP_COLOR = Color.white
EHIWaypoint._GUI_COLOR = Color.white
---@param waypoint Waypoint
---@param params table
function EHIWaypoint:init(waypoint, params)
    self:pre_init(params)
    self._id = params.id --[[@as string]]
    self._time = self._forced_time or params.time or 0
    self._gui = waypoint.timer_gui
    self._bitmap = waypoint.bitmap
    self._arrow = waypoint.arrow
    self._bitmap_world = waypoint.bitmap_world -- VR
    self._remove_on_alarm = params.remove_on_alarm -- Removes waypoint when alarm sounds
    self._hide_on_delete = params.hide_on_delete
    if self._force_format then
        self._gui:set_text(self:Format())
    end
    if params.remove_vanilla_waypoint and params.restore_on_done then
        self._vanilla_waypoint = params.remove_vanilla_waypoint
    end
    self:post_init(params)
end

function EHIWaypoint:pre_init(params)
end

function EHIWaypoint:post_init(params)
end

if EHI:GetOption("time_format") == 1 then
    EHIWaypoint.Format = tweak_data.ehi.functions.FormatSecondsOnly
    EHIWaypoint.FormatTime = tweak_data.ehi.functions.ReturnSecondsOnly
else
    EHIWaypoint.Format = tweak_data.ehi.functions.FormatMinutesAndSeconds
    EHIWaypoint.FormatTime = tweak_data.ehi.functions.ReturnMinutesAndSeconds
end

---@param dt number
function EHIWaypoint:update(dt)
    self._time = self._time - dt
    self._gui:set_text(self:Format())
    if self._time <= 0 then
        self:delete()
    end
end

---@param dt number
function EHIWaypoint:update_fade(dt)
    self._fade_time = self._fade_time - dt
    if self._fade_time <= 0 then
        self:delete()
    end
end

---@param t number
function EHIWaypoint:SetTime(t)
    self._time = t
    self._gui:set_text(self:Format())
end

---@param color Color?
function EHIWaypoint:SetColor(color)
    local c = color or self._DEFAULT_COLOR
    -- Waypoint-less subclasses hold vanilla waypoint objects the mission can remove
    if alive(self._gui) then
        self._gui:set_color(c or self._GUI_COLOR)
    end
    if alive(self._bitmap) then
        self._bitmap:set_color(c or self._BITMAP_COLOR)
    end
    if alive(self._arrow) then
        self._arrow:set_color(c or self._ARROW_COLOR)
    end
end

---@param color Color?
function EHIWaypoint:StopAndSetColor(color)
    self._gui:stop()
    self:SetColor(color)
end

function EHIWaypoint:AddWaypointToUpdate()
    self._parent_class:_add_waypoint_to_update(self)
end

function EHIWaypoint:RemoveWaypointFromUpdate()
    self._parent_class:_remove_waypoint_from_update(self._id)
end

---@param params ElementTrigger
function EHIWaypoint:Run(params)
    self:SetTime(params.time or 0)
    self:SetColor()
    if params.kill_at_end then
        self._hide_on_delete = nil
    end
end

function EHIWaypoint:SwitchToLoudMode()
    if self._remove_on_alarm then
        self:delete()
    end
end

function EHIWaypoint:delete()
    if self._hide_on_delete then
        self._parent_class:HideWaypoint(self._id)
        return
    end
    self._parent_class:RemoveWaypoint(self._id)
end

function EHIWaypoint:destroy()
    if self._vanilla_waypoint then
        self._parent_class:RestoreVanillaWaypoint(self._vanilla_waypoint)
    end
end

if _G.IS_VR then
    EHIWaypointVR = EHIWaypoint
    EHIWaypointVR.old_SetColor = EHIWaypoint.SetColor
    ---@param color Color?
    function EHIWaypointVR:SetColor(color)
        self:old_SetColor(color)
        self._bitmap_world:set_color(color or self._DEFAULT_COLOR or self._BITMAP_COLOR)
    end
end

---@class EHIWaypointLessWaypoint : EHIWaypoint
---@field super EHIWaypoint
EHIWaypointLessWaypoint = class(EHIWaypoint)
function EHIWaypointLessWaypoint:init(waypoint, params)
    self:pre_init(params)
    self._id = params.id --[[@as string]]
    self._remove_on_alarm = params.remove_on_alarm -- Removes waypoint when alarm sounds
    self:post_init(params)
end

---@param id number
---@param icon string
---@param position Vector3
function EHIWaypointLessWaypoint:CreateWaypoint(id, icon, position)
    local waypoint = self._parent_class:_create_vanilla_waypoint(id, icon, position)
    if waypoint then
        self._waypoint_id = id
        self._gui = waypoint.timer_gui
        self._gui:set_text(self:Format())
        self._bitmap = waypoint.bitmap
        self._arrow = waypoint.arrow
        self._bitmap_world = waypoint.bitmap_world
    end
end

---@param id number
function EHIWaypointLessWaypoint:RestoreWaypoint(id)
    local init_data = managers.hud:GetStoredWaypointData(id)
    if init_data then
        self:CreateWaypoint(id, init_data.icon, init_data.position)
    end
end

function EHIWaypointLessWaypoint:RemoveWaypoint()
    if self._waypoint_id then
        local init_data = managers.hud:GetStoredWaypointData(self._waypoint_id) ---@cast init_data -?
        managers.hud:remove_waypoint(self._waypoint_id)
        managers.hud:AddWaypointSoft(self._waypoint_id, init_data)
        self._waypoint_id = nil
        self._gui = nil
        self._bitmap = nil
        self._arrow = nil
        self._bitmap_world = nil
    end
end

function EHIWaypointLessWaypoint:destroy()
    if self._waypoint_id then
        managers.hud:remove_waypoint(self._waypoint_id)
    end
    EHIWaypointLessWaypoint.super.destroy(self)
end

---@class EHIWaypointsLessWaypoint : EHIWaypointLessWaypoint
---@field super EHIWaypointLessWaypoint
EHIWaypointsLessWaypoint = class(EHIWaypointLessWaypoint)
function EHIWaypointsLessWaypoint:init(...)
    self._waypoints = {} ---@type table<number, { gui: Text, bitmap: Bitmap, bitmap_world: Bitmap, arrow: Bitmap }>
    EHIWaypointsLessWaypoint.super.init(self, ...)
end

function EHIWaypointsLessWaypoint:CreateWaypoint(id, icon, position, ...)
    local waypoint = self._parent_class:_create_vanilla_waypoint(id, icon, position)
    if waypoint then
        local data = {}
        data.gui = waypoint.timer_gui
        data.gui:set_text(self:Format())
        data.bitmap = waypoint.bitmap
        data.arrow = waypoint.arrow
        data.bitmap_world = waypoint.bitmap_world
        self:WaypointCreated(data, ...)
        self._waypoints[id] = data
    end
end

---Called when a waypoint is created on the screen with additional parameters passed
---@param waypoint { gui: Text, bitmap: Bitmap, bitmap_world: Bitmap, arrow: Bitmap }
function EHIWaypointsLessWaypoint:WaypointCreated(waypoint, ...)
end

---@param id number
function EHIWaypointsLessWaypoint:RemoveWaypoint(id)
    if table.remove_key(self._waypoints, id) then
        local init_data = managers.hud:GetStoredWaypointData(id) ---@cast init_data -?
        managers.hud:remove_waypoint(id)
        managers.hud:AddWaypointSoft(id, init_data)
    end
end

function EHIWaypointsLessWaypoint:destroy()
    for id, _ in pairs(self._waypoints) do
        managers.hud:remove_waypoint(id)
    end
    EHIWaypointsLessWaypoint.super.super.destroy(self)
end

local Color = Color
---@class EHIWarningWaypoint : EHIWaypoint
---@field super EHIWaypoint
EHIWarningWaypoint = class(EHIWaypoint)
EHIWarningWaypoint._check_anim_progress = false
EHIWarningWaypoint._default_color = Color.white
EHIWarningWaypoint._warning_color = EHI:GetColorFromOption("tracker_waypoint", "warning")
---@param o Text
---@param old_color Color
---@param color Color
---@param icon Bitmap
---@param arrow Bitmap
---@param bitmap_world Bitmap?
---@param start_t number
EHIWarningWaypoint._anim_warning = function(o, old_color, color, icon, arrow, bitmap_world, start_t)
    local c = Color(old_color.r, old_color.g, old_color.b)
    local t = start_t
    while true do
        while t > 0 do
            t = t - coroutine.yield()
            local n = math.sin(t * 180)
            c.r = math.lerp(old_color.r, color.r, n)
            c.g = math.lerp(old_color.g, color.g, n)
            c.b = math.lerp(old_color.b, color.b, n)
            o:set_color(c)
            -- this coroutine runs on o; the other objects are separate and can be removed first
            if alive(icon) then
                icon:set_color(c)
            end
            if alive(arrow) then
                arrow:set_color(c)
            end
            if alive(bitmap_world) then
                bitmap_world:set_color(c)
            end
        end
        t = 1
    end
end

function EHIWarningWaypoint:update(dt)
    EHIWarningWaypoint.super.update(self, dt)
    if self._time <= 10 and not self._anim_started then
        self:AnimateColor(self._check_anim_progress)
        self._anim_started = true
    end
end

---@param check_progress boolean?
---@param color Color?
---@param default_color Color?
function EHIWarningWaypoint:AnimateColor(check_progress, color, default_color)
    if self._gui and alive(self._gui) then
        local start_t = check_progress and (1 - math.min(math.ehi_round(self._time, 0.1) - math.floor(self._time), 0.99)) or 1
        self._gui:animate(self._anim_warning, default_color or self._default_color, color or self._warning_color, self._bitmap, self._arrow, self._bitmap_world, start_t)
    end
end

function EHIWarningWaypoint:SetTime(t)
    self._anim_started = false
    self._gui:stop()
    self._check_anim_progress = t <= 10
    EHIWarningWaypoint.super.SetTime(self, t)
end

function EHIWarningWaypoint:SetCompleted()
    self.update = self.update_fade
    self:StopAndSetColor(Color.green)
end

---@class EHIPausableWaypoint : EHIWaypoint
---@field super EHIWaypoint
EHIPausableWaypoint = class(EHIWaypoint)
EHIPausableWaypoint._paused_color = EHI:GetColorFromOption("tracker_waypoint", "pause")
function EHIPausableWaypoint:pre_init(params)
    self._force_format = params.paused
    self._needs_update = not params.paused
end

---@param params table
function EHIPausableWaypoint:post_init(params)
    self:_set_pause(not self._needs_update)
end

---@param pause boolean
function EHIPausableWaypoint:SetPause(pause)
    self:_set_pause(pause)
    if pause then
        self:RemoveWaypointFromUpdate()
    else
        self:AddWaypointToUpdate()
    end
end

function EHIPausableWaypoint:_set_pause(pause)
    self._paused = pause
    self:SetColor()
end

function EHIPausableWaypoint:SetColor(color)
    color = self._paused and self._paused_color or color
    EHIPausableWaypoint.super.SetColor(self, color)
end

---@class EHIProgressWaypoint : EHIWaypoint, EHIProgressTracker
---@field super EHIWaypoint
EHIProgressWaypoint = class(EHIWaypoint)
EHIProgressWaypoint._needs_update = false
EHIProgressWaypoint._force_format = true
EHIProgressWaypoint.Format = EHIProgressTracker.Format
EHIProgressWaypoint.update = EHIProgressWaypoint.update_fade
EHIProgressWaypoint.FormatProgress = EHIProgressTracker.FormatProgress
EHIProgressWaypoint.IncreaseProgress = EHIProgressTracker.IncreaseProgress
EHIProgressWaypoint.IncreaseProgressMax = EHIProgressTracker.IncreaseProgressMax
EHIProgressWaypoint.DecreaseProgressMax = EHIProgressTracker.DecreaseProgressMax
function EHIProgressWaypoint:pre_init(params)
    self._max = params.max or 0
    self._progress = params.progress or 0
end

---@param progress number?
function EHIProgressWaypoint:DecreaseProgress(progress)
    self:SetProgress(self._progress - (progress or 1))
    self._disable_counting = false
end

---@param progress number
function EHIProgressWaypoint:SetProgress(progress)
    if self._progress ~= progress and not self._disable_counting then
        self._progress = progress
        self._gui:set_text(self:FormatProgress())
        if self._progress == self._max then
            self:SetCompleted()
        end
    end
end

---@param max number
function EHIProgressWaypoint:SetProgressMax(max)
    self._max = max
    self._gui:set_text(self:FormatProgress())
end

function EHIProgressWaypoint:SetCompleted()
    self:SetColor(Color.green)
    self:AddWaypointToUpdate()
end

---@class EHIChanceWaypoint : EHIWaypoint, EHIChanceTracker
---@field super EHIWaypoint
EHIChanceWaypoint = class(EHIWaypoint)
EHIChanceWaypoint._needs_update = false
EHIChanceWaypoint._force_format = true
EHIChanceWaypoint.pre_init = EHIChanceTracker.pre_init
EHIChanceWaypoint.Format = EHIChanceTracker.Format
EHIChanceWaypoint.FormatChance = EHIChanceTracker.FormatChance
EHIChanceWaypoint.DecreaseChance = EHIChanceTracker.DecreaseChance
EHIChanceWaypoint.IncreaseChance = EHIChanceTracker.IncreaseChance
EHIChanceWaypoint.IncreaseChanceIndex = EHIChanceTracker.IncreaseChanceIndex
---@param o Text
---@param self EHIChanceTracker
EHIChanceWaypoint._anim_chance = function(o, self)
    local chance_to_anim = self._anim_static_chance
    if chance_to_anim ~= self._chance then
        local t = 0
        while t < 1 do
            t = t + coroutine.yield()
            local n = math.floor(math.lerp(chance_to_anim, self._chance, t))
            o:set_text(self:FormatChance(n))
            self._anim_static_chance = n
        end
        o:set_text(self:FormatChance())
        self._anim_static_chance = self._chance
    end
end
---@param amount number
function EHIChanceWaypoint:SetChance(amount)
    self._chance = math.max(0, amount)
    if self._anim_static_chance then
        self._gui:stop()
        self._gui:animate(self._anim_chance, self)
    else
        self._gui:set_text(self:FormatChance())
    end
end

---@class EHIWaypointLessChanceWaypoint : EHIWaypointLessWaypoint, EHIChanceWaypoint
---@field super EHIWaypointLessWaypoint
EHIWaypointLessChanceWaypoint = class(EHIWaypointLessWaypoint)
EHIWaypointLessChanceWaypoint._needs_update = false
EHIWaypointLessChanceWaypoint._anim_chance = EHIChanceWaypoint._anim_chance
EHIWaypointLessChanceWaypoint.pre_init = EHIChanceWaypoint.pre_init
EHIWaypointLessChanceWaypoint.Format = EHIChanceWaypoint.Format
EHIWaypointLessChanceWaypoint.FormatChance = EHIChanceWaypoint.FormatChance
EHIWaypointLessChanceWaypoint.DecreaseChance = EHIChanceWaypoint.DecreaseChance
EHIWaypointLessChanceWaypoint.IncreaseChance = EHIChanceWaypoint.IncreaseChance
EHIWaypointLessChanceWaypoint.IncreaseChanceIndex = EHIChanceWaypoint.IncreaseChanceIndex
EHIWaypointLessChanceWaypoint._SetChance = EHIChanceWaypoint.SetChance
function EHIWaypointLessChanceWaypoint:SetChance(amount)
    if not self._gui then
        self._chance = math.max(0, amount)
        return
    end
    self:_SetChance(amount)
end

---@class EHIInaccurateWaypoint : EHIWaypoint
---@field super EHIWaypoint
EHIInaccurateWaypoint = class(EHIWaypoint)
EHIInaccurateWaypoint._DEFAULT_COLOR = EHI:GetColorFromOption("tracker_waypoint", "inaccurate")
function EHIInaccurateWaypoint:post_init(params)
    self:SetColor()
end

---@param time number
function EHIInaccurateWaypoint:SetAccurate(time)
    self._DEFAULT_COLOR = nil
    self:SetColor()
    self:SetTime(time)
end

---@class EHIInaccuratePausableWaypoint: EHIPausableWaypoint
EHIInaccuratePausableWaypoint = class(EHIPausableWaypoint)
EHIInaccuratePausableWaypoint._DEFAULT_COLOR = EHIInaccurateWaypoint._DEFAULT_COLOR
EHIInaccuratePausableWaypoint.SetAccurate = EHIInaccurateWaypoint.SetAccurate

---@class EHIInaccurateWarningWaypoint: EHIWarningWaypoint
EHIInaccurateWarningWaypoint = class(EHIWarningWaypoint)
EHIInaccurateWarningWaypoint._DEFAULT_COLOR = EHIInaccurateWaypoint._DEFAULT_COLOR
EHIInaccurateWarningWaypoint.SetAccurate = EHIInaccurateWaypoint.SetAccurate
function EHIInaccurateWarningWaypoint:post_init(params)
    self:SetColor()
end