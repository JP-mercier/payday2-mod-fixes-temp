Hooks:PostHook(HUDStageEndScreen, "show", "MenuBGsInit", function(self)
	local is_success = game_state_machine:current_state().is_success and game_state_machine:current_state():is_success()
	if not is_success and MenuBackgrounds.Options:GetValue("Menus/failscreen") then
		self._backdrop:set_background("failscreen")
	elseif MenuBackgrounds.Options:GetValue("Menus/endscreen") then
		self._backdrop:set_background("endscreen")
	end
end)

-- The Crime Spree end screen has no "show" of its own (it inherits HUDStageEndScreen's, hooked above),
-- so hooking it only logged "Could not post hook function 'show'" on every load
if HUDStageEndCrimeSpreeScreen and rawget(HUDStageEndCrimeSpreeScreen, "show") then
	Hooks:PostHook(HUDStageEndCrimeSpreeScreen, "show", "MenuSpreeBGsInit", function(self)
		local is_success = game_state_machine:current_state().is_success and game_state_machine:current_state():is_success()
		if not is_success and MenuBackgrounds.Options:GetValue("Menus/failscreen") then
			self._backdrop:set_background("failscreen")
		elseif MenuBackgrounds.Options:GetValue("Menus/endscreen") then
			self._backdrop:set_background("endscreen")
		end
	end)
end

function HUDStageEndScreen:spawn_animation() self:_wait_for_video() end

function HUDStageEndScreen:_wait_for_video()
	if not MenuBackgrounds.Options:GetValue("Menus/endscreen") or not MenuBackgrounds.Options:GetValue("Menus/failscreen") then
		return
	end
	local video = self._background_layer_full:child("money_video")
	video:parent():remove(video)
end
