local function init_pshk(self, tweak_data)
  self.global_value_category.mental = {
    name_id = 'mental_category_name',
    sort_number = 5
  }
end

-- Was hooked on DLCTweakData under the same id as dlc-tweak.lua, so BLT refused it
-- ("Could not post hook function 'init'") and the 'mental' category was never added
Hooks:PostHook(LootDropTweakData, 'init', '@mental/LootDropTweakData/init/post', init_pshk)
