-- mountain master "fix"
if Global.level_data.level_id == 'pent' then return end

local mod_path = ModPath

local function write_tmp(content)
  local filename = content:key()
  local path = string.format("%s/%s", mod_path, filename)

  if not SystemFS:exists(path) then
    local file = io.open(path, "w")
    file:write(content)
    file:close()
  end

  return path
end

local function write_material_config(xml_data)
  local ext = Idstring("material_config")
  local xml = ScriptSerializer:to_custom_xml(xml_data):gsub("<(/?)table", "<%1materials")
  local path = write_tmp(xml)
  local name = path:id()

  DB:create_entry(ext, name, path)

  managers.dyn_resource:load(ext, name, managers.dyn_resource.DYN_RESOURCES_PACKAGE)

  return name
end

local function make_material_config(unit, recurse, opts)
  opts = opts or {}

  local materials = {}
  local callback = opts.clbk
  opts.clbk = nil
  local transform_material = opts.material or function(material_data)
    return material_data
  end
  local variables = opts.vars or {}

  local unit_data = PackageManager:unit_data(unit:name())
  local config_name = unit_data:material_config()

  local file = DB:open("material_config", config_name)

  if not file:at_end() then
    local content = file:read()
    local config_data = ScriptSerializer:from_custom_xml(content)

    local new_config = {
      version = "3",
      group = config_data.group
    }

    for _, material_data in ipairs(config_data) do
      table.insert(new_config, transform_material(material_data))
    end

    local new_config_name = write_material_config(new_config)
    unit:set_material_config(new_config_name, true, callback)

    for _, material_data in ipairs(new_config) do
      local material = unit:material(material_data.name:id())
      table.insert(materials, material)

      for var_name, var_value in pairs(variables) do
        material:set_variable(var_name:id(), var_value)
      end
    end
  end

  if recurse then
    for _, child in ipairs(unit:children()) do
      for _, material in ipairs(make_material_config(child, recurse, opts)) do
        table.insert(materials, material)
      end
    end
  end

  return materials
end

local function find_diffuse(material_data)
  return table.find_value(material_data, function(data)
    return data._meta == "diffuse_texture"
  end)
end

local function cop_material(use_contour, material_data)
  local name = material_data.name
  local diffuse = find_diffuse(material_data)
  local skinned = material_data.render_template and material_data.render_template:match("SKINNED") ~= nil

  local render_template
  if skinned then
    render_template = use_contour
        and "generic:CONTOUR:DIFFUSE_TEXTURE:NORMALMAP:SELF_ILLUMINATION:SELF_ILLUMINATION_BLOOM:SKINNED_3WEIGHTS"
        or "generic:DIFFUSE_TEXTURE:NORMALMAP:RL_COPS:SELF_ILLUMINATION:SELF_ILLUMINATION_BLOOM:SKINNED_3WEIGHTS"
  else
    render_template = "generic:DIFFUSE_TEXTURE:SELF_ILLUMINATION"
  end

  if name == "shadow_caster" or not diffuse then
    return material_data
  end

  return {
    diffuse,
    { _meta = "self_illumination_texture", file = diffuse.file },
    { _meta = "bump_normal_texture",       file = "@glowslop/transparent" },
    { _meta = "variable",                  name = "il_multiplier",        value = "10",       type = "scalar" },
    { _meta = "variable",                  name = "il_bloom",             value = "10000.0", type = "float" },
    { _meta = "variable",                  name = "contour_color",        value = "1 1 1",   type = "vector3" },
    { _meta = "variable",                  name = "contour_opacity",      value = "1",       type = "scalar" },
    { _meta = "variable",                  name = "contour_distance",     value = "100000",  type = "scalar" },
    version = "2",
    _meta = "material",
    name = name,
    unique = "true",
    render_template = render_template
  }
end

local function apply_fullbright(cop_base, use_contour, callback)
  if not alive(cop_base._unit) then
    return
  end

  return make_material_config(cop_base._unit, true, {
    material = function(material_data)
      return cop_material(use_contour, material_data)
    end,
    clbk = callback
  })
end

local function init_hook(hook_id)
  local function init(self)
    call_on_next_update(function()
      apply_fullbright(self, false)
    end)
  end
  Hooks:PostHook(CopBase, "init", hook_id, init)
end

if RequiredScript:match "huskplayercopbase" then
  init_hook("HuskCopBase-glowslop")
elseif RequiredScript:match "copbase" then
  local function swap_material_config(self, callback)
    -- The material config loads asynchronously. Vanilla routes the "material applied" callback
    -- through CopBase:on_material_applied, which bails out when the unit is gone; calling the
    -- contour callback directly ran ContourExt:_upd_color on a deleted unit (native crash in
    -- contourext _upd_color) whenever a cop died or was cleaned up before the swap finished.
    local loaded_clbk = callback and function()
      if alive(self._unit) then
        self:on_material_applied(callback)
      end
    end

    apply_fullbright(self, self._is_in_original_material, loaded_clbk)
    self._is_in_original_material = not self._is_in_original_material

    if not callback then
      self:on_material_applied()
    end
  end
  Hooks:OverrideFunction(CopBase, "swap_material_config", swap_material_config)

  init_hook("CopBase-glowslop")
end
